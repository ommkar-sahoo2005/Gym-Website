import React from "react";
import { NavLink } from "react-router-dom";
import { useState } from "react";
import { FaBars } from "react-icons/fa6";
import "./Links.css";

const abc = {
  links: [
    {
      name: "Home",
      path: "/",
    },
    {
      name: "About",
      path: "/about",
    },
    {
      name: "Gallery",
      path: "/gallery",
    },
    {
      name: "Plans",
      path: "/plans",
    },
    {
      name: "Trainers",
      path: "/trainers",
    },
    {
      name: "Contact",
      path: "/contact",
    },
  ],
};

const Links = () => {
  const [isNavShow, setisNavShow] = useState(false);
  let showNavbar = () => {
    setisNavShow((prev) => !prev);
  };

  return (
    <div>
      <span className={`nav__links ${isNavShow ? "show__nav" : "hide__nav"}`}>
        {abc.links.map((name, index) => (
          <div key={index}>
            <ul>
              <li onClick={showNavbar}>
                <NavLink
                  to={name.path}
                  className={({ isActive }) => (isActive ? "active-nav" : "")}
                >
                  <strong>{name.name}</strong>
                </NavLink>
              </li>
            </ul>
          </div>
        ))}
      </span>
      <span>
        <button className="nav__toggle-btn" onClick={showNavbar}>
          <FaBars />
        </button>
      </span>
    </div>
  );
};

export default Links;
