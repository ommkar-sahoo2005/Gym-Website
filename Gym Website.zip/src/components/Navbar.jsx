import { Link, NavLink } from "react-router-dom";
import React from "react";
import Logo from "../images/logo.png";
import Links from "../data/Links";
import "./Navbar.css";

const Navbar = () => {
  return (
    <nav>
      <div className="container nav__container">
        <Link className="Logo" to="/">
          <img src={Logo} alt="Website Logo" />
        </Link>
        <Links />
      </div>
    </nav>
  );
};

export default Navbar;
