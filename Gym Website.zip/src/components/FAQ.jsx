import React from "react";
import { useState } from "react";
import { FaPlus } from "react-icons/fa";
import { FaMinus } from "react-icons/fa";

const FAQ = ({ question, answer }) => {
  const [isAnswerShowing, setIsAnswerShowing] = useState(false);
  let checkEvent = () => {
    setIsAnswerShowing((prev) => !prev);
  };
  return (
    <article className="faq" onClick={checkEvent}>
      <div>
        <h4>{question}</h4>
        <button className="faq__icon">
          {isAnswerShowing ? <FaMinus /> : <FaPlus />}
        </button>
      </div>
      {isAnswerShowing && <p>{answer}</p>}
    </article>
  );
};

export default FAQ;
