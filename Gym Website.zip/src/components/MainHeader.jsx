import React from "react";

const MainHeader = ({ title, image, children }) => {
  return (
    <header className="main__header">
      <div className="mainHeader__container">
        <div className="mainHeader__container-bg">
          <img src={image} alt="Header Background Image" />
        </div>
        <div className="mainHeader__content">
          <h2>{title}</h2>
          <p>{children}</p>
        </div>
      </div>
    </header>
  );
};

export default MainHeader;
