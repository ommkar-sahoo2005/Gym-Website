import React from "react";
import Image from "../images/values.jpg";
import SectionHead from "./SectionHead";
import Card from "./card";
import { SiOpenaigym } from "react-icons/si";
import { IoDiamondOutline } from "react-icons/io5";

const values = [
  {
    id: 1,
    icon: <SiOpenaigym />,
    title: "Value One",
    desc: "Placeat quidem facere dicta modi? Pariatur exercitationem illum.",
  },
  {
    id: 2,
    icon: <SiOpenaigym />,
    title: "Value Two",
    desc: "Placeat quidem facere dicta modi? Pariatur exercitationem illum.",
  },
  {
    id: 3,
    icon: <SiOpenaigym />,
    title: "Value Three",
    desc: "Placeat quidem facere dicta modi? Pariatur exercitationem illum.",
  },
  {
    id: 4,
    icon: <SiOpenaigym />,
    title: "Value Four",
    desc: "Placeat quidem facere dicta modi? Pariatur exercitationem illum.",
  },
];

const Values = () => {
  return (
    <section className="values">
      <div className="container values__container">
        <div className="values__left">
          <img src={Image} alt="Values Image" />
        </div>
        <div className="values__right">
          <SectionHead icon={<IoDiamondOutline />} title="Values" />
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nesciunt
            impedit in, alias, ut minima corrupti harum, itaque molestias libero
            excepturi accusamus dolores! Odio, consectetur perferendis
            accusantium magnam soluta ipsa tenetur!
          </p>
          <div className="values__wrapper">
            {values.map(({ id, icon, title, desc }) => (
              <Card className="values__value" key={id}>
                <span>{icon}</span>
                <h4>{title}</h4>
                <small>{desc}</small>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Values;
