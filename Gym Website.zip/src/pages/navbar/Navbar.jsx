import React from "react";
import Navbar from "./Navbar.css";

const Navbar = () => {
  return <div>Navbar</div>;
};

export default Navbar;
