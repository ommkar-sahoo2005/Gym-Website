import "./gallery.css";
import HeaderImage from "../../images/header_bg_3.jpg";
import MainHeader from "../../components/MainHeader";
import Image1 from "../../images/gallery1.jpg";
import Image2 from "../../images/gallery2.jpg";
import Image3 from "../../images/gallery3.jpg";
import Image4 from "../../images/gallery4.jpg";
import Image5 from "../../images/gallery5.jpg";
import Image6 from "../../images/gallery6.jpg";
import Image7 from "../../images/gallery7.jpg";
import Image8 from "../../images/gallery8.jpg";
import Image9 from "../../images/gallery9.jpg";
import Image10 from "../../images/gallery10.jpg";
import Image11 from "../../images/gallery11.jpg";
import Image12 from "../../images/gallery12.jpg";
import Image13 from "../../images/gallery13.jpg";
import Image14 from "../../images/gallery14.jpg";
import Image15 from "../../images/gallery15.jpg";

const galleryImages = [
  {
    gallery: Image1,
    alt: "Image 1",
  },
  {
    gallery: Image2,
    alt: "Image 2",
  },
  {
    gallery: Image3,
    alt: "Image 3",
  },
  {
    gallery: Image4,
    alt: "Image 4",
  },
  {
    gallery: Image5,
    alt: "Image 5",
  },
  {
    gallery: Image6,
    alt: "Image 6",
  },
  {
    gallery: Image7,
    alt: "Image 7",
  },
  {
    gallery: Image8,
    alt: "Image 8",
  },
  {
    gallery: Image9,
    alt: "Image 9",
  },
  {
    gallery: Image10,
    alt: "Image 10",
  },
  {
    gallery: Image11,
    alt: "Image 11",
  },
  {
    gallery: Image12,
    alt: "Image 12",
  },
  {
    gallery: Image13,
    alt: "Image 13",
  },
  {
    gallery: Image14,
    alt: "Image 14",
  },
  {
    gallery: Image15,
    alt: "Image 15",
  },
];

const gallery = () => {
  return (
    <div className="gallery__main">
      <MainHeader
        title="Our Gallery"
        image={HeaderImage}
        children="Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam
      voluptas dicta ab nam! Aliquid soluta et deleniti odio repellat
      blanditiis id optio maxime? Quasi nobis id sequi est. Debitis, sunt!"
      />
      <section className="gallery">
        <div className="container gallery__container">
          {galleryImages.map((gallery, index) => (
            <img src={gallery.gallery} alt={gallery.alt} key={index} />
          ))}
        </div>
      </section>
    </div>
  );
};

export default gallery;
