import "./about.css";
import MainHeader from "../../components/MainHeader";
import HeaderImage from "../../images/header_bg_1.jpg";
import StoryImage from "../../images/about1.jpg";
import VisionImage from "../../images/about2.jpg";
import MissionImage from "../../images/about3.jpg";

const About = () => {
  return (
    <div className="about">
      <MainHeader
        title="About Us"
        image={HeaderImage}
        children="Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam
          voluptas dicta ab nam! Aliquid soluta et deleniti odio repellat
          blanditiis id optio maxime? Quasi nobis id sequi est. Debitis, sunt!"
      />

      <section className="about__story">
        <div className="container about__story-container">
          <div className="about__section-image">
            <img src={StoryImage} alt="Our Story Image" />
          </div>
          <div className="about__section-content">
            <h1>Our Story</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima,
              voluptatibus dolore. Repudiandae, doloribus laudantium alias
              possimus quidem odit eius perferendis vero architecto accusantium
              qui, natus aliquid harum asperiores, id aut.
            </p>
            <br></br>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque qui
              ipsam, cumque deleniti nam nesciunt accusantium officia voluptates
              nostrum? Voluptatem nostrum, magni error id beatae possimus
              corrupti dignissimos? Praesentium, quo.
            </p>
            <br></br>
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. At
              veritatis facilis a non molestias, laudantium assumenda iure
              libero, aliquid minima perspiciatis reiciendis placeat repellat ea
              dolorem ducimus dicta omnis eius rerum cum corporis ab? Laborum.
            </p>
            <br></br>
          </div>
        </div>
      </section>
      <section className="about__vision">
        <div className="container about__vision-container">
          <div className="about__section-content">
            <h1>Our Vision</h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima,
              voluptatibus dolore. Repudiandae, doloribus laudantium alias
              possimus quidem odit eius perferendis vero architecto accusantium
              qui, natus aliquid harum asperiores, id aut.
            </p>
            <br></br>
            <p>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim non
              quae nemo aliquid. Debitis consectetur at dolorum dicta odio quas,
              quis qui quibusdam similique numquam accusantium vitae dolorem
              velit quidem quo porro ea, deserunt ex.
            </p>
            <br></br>
          </div>
          <div className="about__section-image">
            <img src={VisionImage} alt="Our Vision Image" />
          </div>
        </div>
      </section>
      <section className="about__mission">
        <div className="container about__mission-container">
          <div className="about__section-image">
            <img src={MissionImage} alt="Our Mission Image" />
          </div>
          <div className="about__mission-content">
            <h1>Our Mission</h1>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Aspernatur mollitia voluptate ullam tenetur cumque quas distinctio
              repudiandae illum eius amet. Expedita, ut a earum facilis quas,
              amet soluta laudantium eum quod perferendis libero unde?
              Voluptates doloribus at, sapiente quos iste mollitia voluptatum
              suscipit, fugiat ipsa totam veritatis vero cupiditate, unde veniam
              expedita omnis nemo! Fugit quia necessitatibus est nisi velit
              cumque suscipit consectetur, alias aliquid!
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
