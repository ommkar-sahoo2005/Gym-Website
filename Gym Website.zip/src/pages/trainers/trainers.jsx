import "./trainers.css";
import MainHeader from "../../components/MainHeader";
import HeaderImage from "../../images/header_bg_5.jpg";
import TrainerComp from "../../components/TrainerComp";
import { FaInstagram } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";
import { FaTwitter } from "react-icons/fa";
import { FaFacebookF } from "react-icons/fa";
import Trainer1 from "../../images/trainer1.jpg";
import Trainer2 from "../../images/trainer2.jpg";
import Trainer3 from "..//../images/trainer3.jpg";
import Trainer4 from "../../images/trainer4.jpg";
import Trainer5 from "../../images/trainer5.jpg";
import Trainer6 from "../../images/trainer6.jpg";

export const trainers = [
  {
    id: 1,
    image: Trainer1,
    name: "John Doe",
    job: "Aerobic Trainer",
    socials: [
      "https://instagram.com/",
      "https://twitter.com/",
      "https://facebook.com/",
      "https://linkedin.com/",
    ],
  },
  {
    id: 2,
    image: Trainer2,
    name: "Daniel vinyo",
    job: "Speed Trainer",
    socials: [
      "https://instagram.com/",
      "https://twitter.com/",
      "https://facebook.com/",
      "https://linkedin.com/",
    ],
  },
  {
    id: 3,
    image: Trainer3,
    name: "Edem Quist",
    job: "Flexibility Trainer",
    socials: [
      "https://instagram.com/",
      "https://twitter.com/",
      "https://facebook.com/",
      "https://linkedin.com/",
    ],
  },
  {
    id: 4,
    image: Trainer4,
    name: "Shatta Wale",
    job: "Body Composition Trainer",
    socials: [
      "https://instagram.com/",
      "https://twitter.com/",
      "https://facebook.com/",
      "https://linkedin.com/",
    ],
  },
  {
    id: 5,
    image: Trainer5,
    name: "Diana Ayi",
    job: "Circuit Trainer",
    socials: [
      "https://instagram.com/",
      "https://twitter.com/",
      "https://facebook.com/",
      "https://linkedin.com/",
    ],
  },
  {
    id: 6,
    image: Trainer6,
    name: "Wayne Carter",
    job: "Physical Intelligence Trainer",
    socials: [
      "https://instagram.com/",
      "https://twitter.com/",
      "https://facebook.com/",
      "https://linkedin.com/",
    ],
  },
];

const trainer = () => {
  return (
    <>
      <MainHeader
        title="Our Trainer"
        image={HeaderImage}
        children="Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam
          voluptas dicta ab nam! Aliquid soluta et deleniti odio repellat
          blanditiis id optio maxime? Quasi nobis id sequi est. Debitis, sunt!"
      />
      <section className="trainers">
        <div className="container trainers__container">
          {trainers.map(({ id, image, name, job, socials }) => (
            <TrainerComp
              key={id}
              image={image}
              name={name}
              job={job}
              socials={[
                { icon: <FaInstagram />, link: socials[0] },
                { icon: <FaTwitter />, link: socials[1] },
                { icon: <FaFacebookF />, link: socials[2] },
                { icon: <FaLinkedin />, link: socials[3] },
              ]}
            />
          ))}
        </div>
      </section>
    </>
  );
};

export default trainer;
