import "./notFound.css";
import { Link } from "react-router-dom";

const NotFound = () => {
  return (
    <main className="not-found">
      <div className="container not-found__container">
        <h2 role="alert">Page Not Found</h2>
        <Link to="/" className="btn">
          Go Back Home
        </Link>
      </div>
    </main>
  );
};

export default NotFound;
