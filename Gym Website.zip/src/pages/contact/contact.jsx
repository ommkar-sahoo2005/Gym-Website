import "./contact.css";
import Header from "../../images/header_bg_2.jpg";
import MainHeader from "../../components/MainHeader";
import { CiMail } from "react-icons/ci";
import { FaTelegram } from "react-icons/fa";
import { FaWhatsapp } from "react-icons/fa";

const contact = () => {
  return (
    <>
      <MainHeader
        title="Get In Touch"
        image={Header}
        children="Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam
          voluptas dicta ab nam! Aliquid soluta et deleniti odio repellat
          blanditiis id optio maxime? Quasi nobis id sequi est. Debiti"
      />
      <section className="contact">
        <div className="container contact__container">
          <div className="contact__wrapper">
            <a
              href="mailto:ommkarsahoo2005@gmail.com"
              target="_blank"
              rel="noreferrer noopener"
            >
              <CiMail />
            </a>
            <a
              href="https://t.me/JeeHaiPadhLo"
              target="_blank"
              rel="noreferrer noopener"
            >
              <FaTelegram />
            </a>
            <a
              href="https://api.whatsapp.com/qr/NEY6J6JTFMOGE1?autoload=1&app_absent=0"
              target="_blank"
              rel="noreferrer noopener"
            >
              <FaWhatsapp />
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default contact;
